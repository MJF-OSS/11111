#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
试卷批改系统 - Web 版本
Flask + SQLite + Tesseract OCR
"""

from flask import Flask, render_template, request, redirect, url_for, flash, session, send_from_directory
from werkzeug.utils import secure_filename
import os
import sqlite3
from datetime import datetime
import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont
import pandas as pd
import json
import re
import pytesseract

app = Flask(__name__)
app.secret_key = 'exam-grader-secret-key-2026'

# 配置
UPLOAD_FOLDER = 'static/uploads'
RESULT_FOLDER = 'static/results'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}
DATABASE = 'database.db'

# 固定账号密码（单用户模式）
ADMIN_USERNAME = 'admin'
ADMIN_PASSWORD = 'admin123'


def get_db():
    db = sqlite3.connect(DATABASE)
    db.row_factory = sqlite3.Row
    return db


def init_db():
    db = get_db()
    db.execute('''
        CREATE TABLE IF NOT EXISTS grading_records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            filename TEXT NOT NULL,
            original_path TEXT NOT NULL,
            result_path TEXT,
            total_score REAL,
            earned_score REAL,
            details TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    db.commit()
    db.close()


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


def preprocess_image(img):
    """预处理图片以提高 OCR 准确率"""
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    # 自适应二值化
    binary = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                    cv2.THRESH_BINARY, 11, 2)
    # 轻微去噪
    denoised = cv2.fastNlMeansDenoising(binary, h=10)
    return denoised


def ocr_exam(image_path):
    """OCR 识别学生答卷"""
    img = cv2.imread(image_path)
    if img is None:
        raise ValueError(f"无法读取图片: {image_path}")

    processed = preprocess_image(img)

    # 使用 tesseract 进行 OCR，支持中英文
    custom_config = r'--oem 3 --psm 6'
    ocr_data = pytesseract.image_to_data(processed, lang='chi_sim+eng',
                                          config=custom_config, output_type=pytesseract.Output.DICT)

    # 合并同一行的文字
    n_boxes = len(ocr_data['text'])
    lines = {}
    for i in range(n_boxes):
        text = ocr_data['text'][i].strip()
        if not text:
            continue
        block_num = ocr_data['block_num'][i]
        par_num = ocr_data['par_num'][i]
        line_num = ocr_data['line_num'][i]
        key = (block_num, par_num, line_num)
        if key not in lines:
            lines[key] = {'text': '', 'x': ocr_data['left'][i], 'y': ocr_data['top'][i],
                          'w': ocr_data['width'][i], 'h': ocr_data['height'][i]}
        else:
            lines[key]['text'] += ' ' + text
            lines[key]['w'] = (ocr_data['left'][i] + ocr_data['width'][i]) - lines[key]['x']

    student_answers = {}
    for key, line in lines.items():
        text = line['text'].strip()
        # 匹配题号和答案的模式
        patterns = [
            r'(\d+)\s*[.、．)\]）]\s*([A-Da-d])',
            r'(\d+)\s*[.、．)\]）]\s*(\S+)',
            r'第\s*(\d+)\s*题\s*[:：]?\s*([A-Da-d])',
            r'第\s*(\d+)\s*题\s*[:：]?\s*(\S+)',
        ]
        for pattern in patterns:
            match = re.search(pattern, text)
            if match:
                q_num = match.group(1)
                answer = match.group(2).strip().upper()
                position = [
                    [line['x'], line['y']],
                    [line['x'] + line['w'], line['y']],
                    [line['x'] + line['w'], line['y'] + line['h']],
                    [line['x'], line['y'] + line['h']]
                ]
                student_answers[q_num] = {
                    'answer': answer,
                    'position': position,
                    'text': text
                }
                break

    return student_answers, img


def grade_exam(student_answers, standard_answers):
    """对比答案并评分"""
    total_score = sum(q['score'] for q in standard_answers.values())
    earned_score = 0
    details = []

    for q_num, standard in standard_answers.items():
        student = student_answers.get(q_num, {})
        student_ans = student.get('answer', '未识别')

        is_correct = False
        comment = ""

        if standard['type'] in ['选择', '填空']:
            is_correct = student_ans == standard['answer']
            if not is_correct:
                comment = f"正确答案: {standard['answer']}"
        elif standard['type'] == '主观':
            keywords = [k.strip() for k in standard.get('keywords', '').split(',') if k.strip()]
            if keywords:
                matched = sum(1 for kw in keywords if kw in student_ans)
                keyword_ratio = matched / len(keywords)
                if keyword_ratio >= 0.6:
                    is_correct = True
                    earned_score += standard['score']
                elif keyword_ratio > 0:
                    partial = round(standard['score'] * keyword_ratio, 1)
                    earned_score += partial
                    comment = f"关键词命中 {matched}/{len(keywords)}，得 {partial}/{standard['score']} 分"
                else:
                    comment = f"未命中关键词"
            else:
                comment = "未设置关键词，请人工批阅"

        if is_correct and standard['type'] in ['选择', '填空']:
            earned_score += standard['score']

        details.append({
            'question_num': q_num,
            'standard_answer': standard['answer'],
            'student_answer': student_ans,
            'is_correct': is_correct,
            'score': standard['score'],
            'earned_score': standard['score'] if is_correct else (earned_score if standard['type'] == '主观' else 0),
            'type': standard['type'],
            'comment': comment,
            'position': student.get('position', None)
        })

    # 修正 earned_score 计算
    earned_score = sum(d['earned_score'] for d in details)
    return total_score, earned_score, details


def draw_annotations(img, details, total_score, earned_score, output_path):
    """在图片上绘制批改标记"""
    img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    pil_img = Image.fromarray(img_rgb)
    draw = ImageDraw.Draw(pil_img)

    # 尝试加载中文字体
    font = None
    font_paths = [
        '/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc',
        '/usr/share/fonts/wqy-zenhei/wqy-zenhei.ttc',
        '/usr/share/fonts/truetype/droid/DroidSansFallbackFull.ttf',
        '/System/Library/Fonts/PingFang.ttc',
    ]
    for fp in font_paths:
        if os.path.exists(fp):
            font = ImageFont.truetype(fp, 20)
            break
    if font is None:
        try:
            font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 18)
        except:
            font = ImageFont.load_default()

    for detail in details:
        if detail['position'] is None:
            continue

        pos = detail['position']
        x = int(pos[0][0])
        y = int(pos[0][1])

        if detail['is_correct']:
            # 画红勾 ✓
            draw.line([(x + 60, y + 15), (x + 70, y + 25), (x + 85, y + 5)],
                      fill=(255, 0, 0), width=3)
        else:
            # 画红叉 ✗
            draw.line([(x + 60, y + 5), (x + 80, y + 25)], fill=(255, 0, 0), width=3)
            draw.line([(x + 80, y + 5), (x + 60, y + 25)], fill=(255, 0, 0), width=3)
            # 标注正确答案
            label = f"Ans: {detail['standard_answer']}"
            draw.text((x + 90, y), label, fill=(255, 0, 0), font=font)

        if detail['comment']:
            draw.text((x + 90, y + 25), detail['comment'], fill=(0, 0, 200), font=font)

    # 右上角显示总分
    score_text = f"Score: {earned_score}/{total_score}"
    draw.text((pil_img.width - 250, 20), score_text, fill=(255, 0, 0), font=font)

    result_img = cv2.cvtColor(np.array(pil_img), cv2.COLOR_RGB2BGR)
    cv2.imwrite(output_path, result_img)


# ==================== Flask 路由 ====================

@app.route('/')
def index():
    if 'username' not in session:
        return redirect(url_for('login'))
    return render_template('index.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
            session['username'] = username
            flash('登录成功！', 'success')
            return redirect(url_for('index'))
        else:
            flash('用户名或密码错误', 'error')
    return render_template('login.html')


@app.route('/logout')
def logout():
    session.pop('username', None)
    flash('已退出登录', 'success')
    return redirect(url_for('login'))


@app.route('/upload', methods=['POST'])
def upload():
    if 'username' not in session:
        return redirect(url_for('login'))

    if 'standard_answers' not in request.files:
        flash('请上传标准答案文件', 'error')
        return redirect(url_for('index'))

    if 'exam_image' not in request.files:
        flash('请上传学生答卷图片', 'error')
        return redirect(url_for('index'))

    standard_file = request.files['standard_answers']
    exam_file = request.files['exam_image']

    if standard_file.filename == '' or exam_file.filename == '':
        flash('请选择文件', 'error')
        return redirect(url_for('index'))

    if not allowed_file(exam_file.filename):
        flash('答卷图片格式不支持，请上传 PNG/JPG 文件', 'error')
        return redirect(url_for('index'))

    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    standard_filename = secure_filename(standard_file.filename)
    exam_filename = secure_filename(exam_file.filename)

    standard_path = os.path.join(UPLOAD_FOLDER, f'{timestamp}_standard_{standard_filename}')
    exam_path = os.path.join(UPLOAD_FOLDER, f'{timestamp}_{exam_filename}')

    standard_file.save(standard_path)
    exam_file.save(exam_path)

    try:
        # 读取标准答案
        df = pd.read_excel(standard_path)
        standard_answers = {}
        for _, row in df.iterrows():
            q_num = str(row.get('题号', '')).strip()
            if not q_num:
                continue
            standard_answers[q_num] = {
                'answer': str(row.get('答案', '')).strip().upper(),
                'score': float(row.get('分值', 0)),
                'type': str(row.get('题型', '选择')).strip(),
                'keywords': str(row.get('关键词', '')).strip()
            }

        if not standard_answers:
            flash('标准答案文件为空或格式不正确', 'error')
            return redirect(url_for('index'))

        # OCR 识别
        student_answers, img = ocr_exam(exam_path)

        # 评分
        total_score, earned_score, details = grade_exam(student_answers, standard_answers)

        # 绘制批改标记
        result_filename = f'{timestamp}_result.jpg'
        result_path = os.path.join(RESULT_FOLDER, result_filename)
        draw_annotations(img, details, total_score, earned_score, result_path)

        # 保存记录到数据库
        db = get_db()
        db.execute(
            'INSERT INTO grading_records (filename, original_path, result_path, total_score, earned_score, details) VALUES (?, ?, ?, ?, ?, ?)',
            (exam_filename, exam_path, result_filename, total_score, earned_score,
             json.dumps(details, ensure_ascii=False, default=str))
        )
        db.commit()
        record_id = db.execute('SELECT last_insert_rowid()').fetchone()[0]
        db.close()

        flash('批改完成！', 'success')
        return redirect(url_for('result', record_id=record_id))

    except Exception as e:
        flash(f'批改失败: {str(e)}', 'error')
        return redirect(url_for('index'))


@app.route('/result/<int:record_id>')
def result(record_id):
    if 'username' not in session:
        return redirect(url_for('login'))

    db = get_db()
    record = db.execute('SELECT * FROM grading_records WHERE id = ?', (record_id,)).fetchone()
    db.close()

    if not record:
        flash('记录不存在', 'error')
        return redirect(url_for('history'))

    details = json.loads(record['details'])

    return render_template('result.html', record=record, details=details)


@app.route('/history')
def history():
    if 'username' not in session:
        return redirect(url_for('login'))

    db = get_db()
    records = db.execute('SELECT * FROM grading_records ORDER BY created_at DESC').fetchall()
    db.close()

    return render_template('history.html', records=records)


@app.route('/download/<filename>')
def download(filename):
    if 'username' not in session:
        return redirect(url_for('login'))
    return send_from_directory(RESULT_FOLDER, filename, as_attachment=True)


if __name__ == '__main__':
    init_db()
    os.makedirs(UPLOAD_FOLDER, exist_ok=True)
    os.makedirs(RESULT_FOLDER, exist_ok=True)

    port = int(os.environ.get('PORT', 5000))
    print("=" * 50)
    print("试卷批改系统已启动")
    print(f"端口: {port}")
    print(f"登录账号: {ADMIN_USERNAME}")
    print(f"登录密码: {ADMIN_PASSWORD}")
    print("=" * 50)

    app.run(debug=False, host='0.0.0.0', port=port)
