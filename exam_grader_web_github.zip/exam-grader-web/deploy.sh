#!/bin/bash
# 试卷批改系统 - 一键部署脚本
# 使用方法: bash deploy.sh

echo "=========================================="
echo "  试卷批改系统 - 云服务器部署"
echo "=========================================="

# 1. 安装系统依赖
echo ">>> 安装系统依赖..."
apt-get update
apt-get install -y python3 python3-pip python3-venv tesseract-ocr tesseract-ocr-chi-sim nginx

# 2. 创建项目目录
PROJECT_DIR=/opt/exam_grader
mkdir -p $PROJECT_DIR
cp -r ./* $PROJECT_DIR/
cd $PROJECT_DIR

# 3. 创建虚拟环境
echo ">>> 创建 Python 虚拟环境..."
python3 -m venv venv
source venv/bin/activate

# 4. 安装 Python 依赖
echo ">>> 安装 Python 依赖..."
pip install --upgrade pip
pip install -r requirements.txt

# 5. 配置 Gunicorn
echo ">>> 配置 Gunicorn..."
cat > gunicorn_config.py << 'GUNICORN'
bind = "127.0.0.1:5000"
workers = 2
timeout = 120
accesslog = "/var/log/exam_grader_access.log"
errorlog = "/var/log/exam_grader_error.log"
GUNICORN

# 6. 配置 systemd 服务
echo ">>> 配置系统服务..."
cat > /etc/systemd/system/exam_grader.service << 'SERVICE'
[Unit]
Description=Exam Grader Web Application
After=network.target

[Service]
User=root
WorkingDirectory=/opt/exam_grader
Environment="PATH=/opt/exam_grader/venv/bin"
ExecStart=/opt/exam_grader/venv/bin/gunicorn -c gunicorn_config.py app:app

Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
SERVICE

systemctl daemon-reload
systemctl enable exam_grader
systemctl start exam_grader

# 7. 配置 Nginx
echo ">>> 配置 Nginx..."
cat > /etc/nginx/sites-available/exam_grader << 'NGINX'
server {
    listen 80;
    server_name _;  # 改为你的域名或公网IP
    
    client_max_body_size 50M;  # 允许上传大文件
    
    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
    
    location /static/ {
        alias /opt/exam_grader/static/;
        expires 30d;
    }
}
NGINX

ln -sf /etc/nginx/sites-available/exam_grader /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default
nginx -t
systemctl restart nginx

# 8. 获取公网IP
PUBLIC_IP=$(curl -s http://ifconfig.me)

echo ""
echo "=========================================="
echo "  ✅ 部署完成！"
echo "=========================================="
echo ""
echo "访问地址: http://$PUBLIC_IP"
echo "登录账号: admin"
echo "登录密码: admin123"
echo ""
echo "重要提示:"
echo "1. 确保云服务器安全组/防火墙开放 80 端口"
echo "2. 建议尽快修改默认密码"
echo "3. 如需域名访问，请将域名解析到 $PUBLIC_IP"
echo ""
