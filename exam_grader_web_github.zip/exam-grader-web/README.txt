==========================================
  试卷批改系统 - 云服务器部署指南
==========================================

【系统要求】
- Ubuntu 20.04/22.04 或 Debian 11/12
- 至少 1核1G 内存
- 10G 硬盘空间

【部署步骤】

第一步：上传项目文件
1. 将 exam_grader_web 文件夹上传到云服务器
   方法：SCP / SFTP / 直接下载

第二步：运行部署脚本
ssh root@你的服务器IP
cd exam_grader_web
bash deploy.sh

第三步：开放端口
在云服务器控制台的安全组/防火墙中，开放 80 端口（HTTP）

第四步：访问系统
浏览器访问 http://你的服务器公网IP
登录账号: admin
登录密码: admin123

【重要提示】
1. 部署完成后立即修改默认密码
2. 如需域名访问，将域名解析到服务器公网IP
3. 如需 HTTPS，可后续配置 Let's Encrypt 证书

【文件说明】
- app.py              主程序
- database.db         数据库（自动生成）
- templates/          网页模板
- static/             静态文件
- requirements.txt    Python依赖
- deploy.sh           一键部署脚本

【常见问题】
Q: 部署脚本报错怎么办？
A: 确认系统是 Ubuntu/Debian，如果是 CentOS 需要修改脚本中的 apt-get 为 yum

Q: 访问不了网站？
A: 检查安全组是否开放 80 端口，检查 nginx 是否启动：systemctl status nginx

Q: 如何修改密码？
A: 编辑 app.py 中的 LOGIN_USERS 字典
